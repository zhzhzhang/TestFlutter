import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';
import 'package:eh_parents_flutter_biz/community/feeds/feed.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/child_crossing_store.dart';
import 'package:flutter/cupertino.dart';
import 'package:infrastructure/tracker/src/eh_tracker.dart';

class ChildCrossingTracker{
  ChildCrossingStore dynamicStore;
  Feed feed;
  String title;
  BuildContext context;
  ChildCrossingTracker(this.context, this.feed, this.title);

  Map<String, String> _commonParam() {
    String resource_id = feed.rawData.programCell.item.ugcItemId.toString() ?? '';
    String resource_mod = '';
    if(feed.contentType == UgcItemContentType.UgcItemContentTypeImageText) resource_mod = 'photo';
    else if(feed.rawData.programCell.item.video.hasVideo()) resource_mod = 'video';
    else resource_mod = 'audio';
    return {
      'resource_id' : resource_id,
      'resource_mod' : resource_mod,
      'title' : title
    };
  }

  void itemLike(bool isLike) {
    String status = isLike == true ? '0' : '1';
    Map _param = _commonParam();
    _param['status'] = status;
    EHTracker.onEvent('hardware_content_like',
        extMap: _param, context: context);
  }

  void itemDownloadClick() {
    Map _param = _commonParam();
    EHTracker.onEvent('hardware_content_download_click',
        extMap: _param, context: context);
  }

  void itemDownloadSuccess() {
    Map _param = _commonParam();
    EHTracker.onEvent('hardware_content_download_success',
        extMap: _param, context: context);
  }

  void itemSetVisibleClick(bool isOnlySelfVisible){
    Map _param = _commonParam();
    String status = isOnlySelfVisible == false ? 'private' : 'public';
    _param['status'] = status;
    EHTracker.onEvent('hardware_content_privacy_set',
        extMap: _param, context: context);
  }

  void itemDeleteClick(){
    Map _param = _commonParam();
    _param['from'] = 'hardware_content_square';
    EHTracker.onEvent('hardware_content_delete_click',
        extMap: _param, context: context);
  }

  void itemDeleteSuccess(){
    Map _param = _commonParam();
    _param['from'] = 'hardware_content_square';
    EHTracker.onEvent('hardware_content_delete_success',
        extMap: _param, context: context);
  }

}