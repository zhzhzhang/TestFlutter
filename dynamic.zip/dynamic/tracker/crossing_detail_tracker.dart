import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/crossing_detail_store.dart';
import 'package:flutter/material.dart';
import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';

import '../../../common/commonimports.dart';

class CrossingDetailTracker {
  ChildUgcDetail detailStore;
  BuildContext context;
  CrossingDetailTracker(this.context);
  bool _ifLoaded = false;
  int _startTime = DateTime.now().millisecondsSinceEpoch;
  int over_cnt = 0;
  bool hasPlayed = false;

  Map<String, String> _detailCommonParam() {
    UgcItemDetailResp _detailResp = detailStore.fetchDetailFuture.result;
    String resource_id = _detailResp.item.ugcItemId.toString() ?? '';
    String resource_mod = '';
    if(detailStore.pageType == UgcItemContentType.UgcItemContentTypeImageText) resource_mod = 'photo';
    else if(detailStore.ugcType.hasVideo()) resource_mod = 'video';
    else resource_mod = 'audio';
    String title = detailStore.title;
    return {
      'resource_id' : resource_id,
      'resource_mod' : resource_mod,
      'title' : title
    };
  }

  void pageAppear() {
    if (_ifLoaded) {
      detailLoad(show: true);
    }
  }

  // 进入详情
  void detailLoad({bool show = false}) {
    if (_ifLoaded == false || show == true) {
      Map _param = _detailCommonParam();
      _startTime = DateTime.now().millisecondsSinceEpoch;
      detailStore?.initParam();
      EHTracker.onEvent('hardware_content_detail_view',
          extMap: _param, context: context);
    }
    _ifLoaded = true;
  }

  // 离开详情
  void detailLeft() {
    UgcItemDetailResp _detailResp = detailStore?.fetchDetailFuture?.result;
    if (detailStore == null || _detailResp == null) {
      return;
    }
    Map _param = _detailCommonParam();
    String _duration =(DateTime.now().millisecondsSinceEpoch - _startTime).toString();
    _param['over_cnt'] = over_cnt.toString();
    _param['duration'] = _duration;
    EHTracker.onEvent('hardware_content_detail_left',
        extMap: _param, context: context);
  }

  void itemLike(bool isLike) {
    String status = isLike == true ? '0' : '1';
    Map _param = _detailCommonParam();
    _param['status'] = status;
    EHTracker.onEvent('hardware_content_like',
        extMap: _param, context: context);
  }

  void itemDownloadClick() {
    Map _param = _detailCommonParam();
    EHTracker.onEvent('hardware_content_download_click',
        extMap: _param, context: context);
  }

  void itemDownloadSuccess() {
    Map _param = _detailCommonParam();
    EHTracker.onEvent('hardware_content_download_success',
        extMap: _param, context: context);
  }

  void itemSetVisibleClick(bool isOnlySelfVisible){
    Map _param = _detailCommonParam();
    String status = isOnlySelfVisible == false ? 'private' : 'public';
    _param['status'] = status;
    EHTracker.onEvent('hardware_content_privacy_set',
        extMap: _param, context: context);
  }

  void itemDeleteClick(){
    Map _param = _detailCommonParam();
    _param['from'] = 'content_detail';
    EHTracker.onEvent('hardware_content_delete_click',
        extMap: _param, context: context);
  }

  void itemDeleteSuccess(){
    Map _param = _detailCommonParam();
    _param['from'] = 'content_detail';
    EHTracker.onEvent('hardware_content_delete_success',
        extMap: _param, context: context);
  }
}
