
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/crossing_detail_store.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/tracker/crossing_detail_tracker.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/detail_exception_widget.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/detail_feed_widget.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/detail_image_slider.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/detail_info_card.dart';
import 'package:flutter/material.dart';
import 'package:eh_parents_flutter_biz/community/ugc_detail/widget/ugc_exception_widget.dart';
import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import '../../common/commonimports.dart';
import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';

class CrossingDetailPage extends EHBasePage {
  CrossingDetailPage(Map routeParams) : super(routeParams);

  @override
  _ImageDetailPageState createState() => _ImageDetailPageState();
}

class _ImageDetailPageState extends EHBasePageState<CrossingDetailPage> {
  ChildUgcDetail detailStore;
  CrossingDetailTracker tracker;
  UgcFeedWidget _videoWidget;
  ScrollController _controller = ScrollController();

  @override
  void onCreate() {
    super.onCreate();
    detailStore = ChildUgcDetail(itemId: int.parse(paramForKey('ugcItemId')), childId: int.parse(paramForKey('deviceUserId')));
    detailStore.fetchDetail();
    detailStore.initDetail(
      isTeamOpen: paramForKey('isTeamOpen') == true ? true : false,
      isContentDisplayOpen: paramForKey('isContentDisplayOpen') == true ? true : false,
      isOnlySelfVisible: paramForKey('isOnlySelfVisible') == true ? true : false
    );
  }

  @override
  void onAppear() {
    super.onAppear();
    _videoWidget?.play();
    tracker?.pageAppear();
  }

  @override
  void onDisappear() {
    super.onDisappear();
    _videoWidget?.pause();
    tracker?.detailLeft();
  }

  @override
  void onDestroy() {
    _controller.dispose();
    super.onDestroy();
  }

  void _initState() {
    final UgcItemDetailResp _result =
        detailStore.fetchDetailFuture.result;
    detailStore.ugcType = _result.item.video;
    detailStore.ugcChannelTag = _result.item.channelExt.channelTag ?? "孩子发布的动态";
    detailStore.pageType = _result.item.contentType;
    detailStore.channelType = _result.item.channelType;
    if(UgcItemChannelType.UgcItemTypeProgramSTU == detailStore.channelType) detailStore.title = _result.lesson.name;
    else if(UgcItemChannelType.UgcItemTypeTeamSTU == detailStore.channelType) detailStore.title = _result.item.title;
    else detailStore.title = _result.item.text;
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          Provider<ChildUgcDetail>(create: (_) => detailStore),
          Provider<CrossingDetailTracker>(
            create: (_) => tracker = CrossingDetailTracker(context),
          )
        ],
        child: Observer(builder: (_) {
          switch (detailStore.detailServiceStatus) {
            case UgcDetailState.pending:
              return PendingWidget();
            case UgcDetailState.error:
              return DetailError(
                ugcItemId: detailStore.itemId,
              );
            case UgcDetailState.empty:
              return DetailEmptyWidget();
            case UgcDetailState.success:
              _initState();
              tracker.detailStore = detailStore;
              detailStore.tracker = tracker;
              tracker?.detailLoad();
              return EHScaffold(
                isExtend: true,
                body:  Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    _buildBody(),
                    _navigationBar(),
                  ],
                ),
              );
          }
          return EmptyWidget();
        }));
  }
  Widget _navigationBar(){
    return Positioned(
      top: 15+EHBaseInfo.deviceConst.inset_top,
      left: 20.0,
      right: 20.0,
      child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            GestureDetector(
              onTap: () {
                FocusScope.of(context).requestFocus(FocusNode()); //?????
                EHRoute.pop();
              },
              child: EHImage.asset(
                EHUikit.getPathForInfraImage('app_bar_back_light.png'),
                width: 20,
                height: 20,
              ),
            ),
            Spacer(),
            GestureDetector(
              onTap: _actionSheet,
              child: EHImage.asset(
                EHUikit.getPathForInfraImage('app_bar_more_light.png') ,
                width: 30,
                height: 30,
                //fit: BoxFit.fitHeight,
              ),
            ),
          ],
        ),
      );
  }

  Widget _buildBody() {
    Widget child;
    if (detailStore.pageType != UgcItemContentType.UgcItemContentTypeVideo) {
          child = Stack(
            children: <Widget>[
              Observer(builder: (_) {
                if (detailStore.hasDetailResults) {
                  final UgcItemDetailResp _result = detailStore.fetchDetailFuture.result;
                  List<String> _imageList = _result?.item?.imageList?.map((value) {
                    if (value?.urlList != null && value.urlList.length > 0) {
                      return value?.urlList[0];
                    } else {
                      return '';
                    }
                  })?.toList();
                  if (!(_imageList != null && _imageList.length > 0)) {
                    return Container();
                  }
                  return Container(
                    padding: EdgeInsets.only(bottom: MediaQuery.of(context).padding.bottom),
                    color: Colors.black,
                    child: UgcImageSlider(
                      context: context,
                      imageList: _imageList,
                    ),
                  );
                }
                else {
                  return Container();
                }
              }),
              UgcInfoText(videoPlayingOrStopped: true,),
              UgcLike(videoPlayingOrStopped: true,)
            ],
        );
    }
    else {
      if (_videoWidget == null)
        _videoWidget = UgcFeedWidget();
      child = _videoWidget;
    }
    return  child;

  }

  List<String> _actionButton() {
    final UgcItemDetailResp _result =
        detailStore?.fetchDetailFuture?.result;
    List<String> _list = List();
    if (detailStore?.pageType == UgcItemContentType.UgcItemContentTypeImageText || _result.item.video.hasVideo()){
      _list.add("保存到相册");
    }
    _list.add(detailStore.isOnlySelfVisible?"设为公开":"设为私密");
    _list.add('删除');
    return _list;
  }

  void _actionSheet(){
    List<String> action = _actionButton();
    int rows = action.length;
    EHActionSheet.show(_actionButton(), '取消', (int index)
    {
      if (index == rows-1) {
        tracker.itemDeleteClick();
        EHDialog.show(
            title: '删除作业',
            message: '动态不会占用手机储存。如果删除会导致孩子也不可再看到该动态内容，是否确定删除？',
            leftText: '取消',
            rightText: '删除',
            rightAction: () {
              detailStore.deleteChildDetail();
            }
        );
      } else if (index == rows-2) {
        final UgcItemUserStatus status = detailStore.isOnlySelfVisible?UgcItemUserStatus.UgcItemUserStatusPUBLIC:UgcItemUserStatus.UgcItemUserStatusPRIVATE;
        tracker.itemSetVisibleClick(detailStore.isOnlySelfVisible);
        if(status == UgcItemUserStatus.UgcItemUserStatusPUBLIC){
          if(detailStore.ugcChannelTag == "组队学习" && !detailStore.isTeamOpen) {
            EHToast.show("组队权限未开启");
            return true;
          }
          else if(detailStore.ugcChannelTag != "组队学习" && !detailStore.isContentDisplayOpen) {
            EHToast.show("分享权限未开启");
            return true;
          }
        }
        detailStore.setUgcVisible(status);
        EHToast.show(detailStore.isOnlySelfVisible == true ? "已公开":"已设为仅家长和孩子可见");
      }
      else if(rows > 2 && index == rows-3){
        tracker.itemDownloadClick();
        detailStore.saveToLocal();
      }
      return true;
    });
  }
}