import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';
import 'package:eh_parents_flutter_biz/community/ugc_detail/state/ugc_detail.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/tracker/crossing_detail_tracker.dart';
import 'package:infrastructure/account/src/eh_account.dart';
import 'package:infrastructure/common/src/dispatch_event_define.dart';
import 'package:infrastructure/plugin/src/utility_plugin.dart';
import 'package:infrastructure/widgets/eh_toast.dart';
import 'package:eh_video_player/eh_video_player.dart';
import 'package:mobx/mobx.dart';
part 'crossing_detail_store.g.dart';


enum UgcDetailState { pending, error, success, empty }

class ChildUgcDetailEvent {
  UgcDetailEventType type;
  Int64 itemId;
  ChildUgcDetailEvent(this.type, this.itemId);
}

class ChildUgcDetail extends _ChildUgcDetail with _$ChildUgcDetail{
  ChildUgcDetail({int itemId, int childId}){
    this.itemId = itemId;
    this.childId = childId;
  }

  void initDetail({
    bool isTeamOpen,
    bool isContentDisplayOpen,
    bool isOnlySelfVisible
  }){
    this.isTeamOpen = isTeamOpen;
    this.isContentDisplayOpen = isContentDisplayOpen;
    this.isOnlySelfVisible = isOnlySelfVisible;
  }

  void saveToLocal() async {
    if(fetchDetailFuture?.status == FutureStatus.fulfilled){
      UgcItemDetailResp _detail = fetchDetailFuture.result;
      if (_detail.item?.contentType == UgcItemContentType.UgcItemContentTypeImageText) {
        saveImage(_detail);
      }
      else {
        bool success = await savePlugin(_detail.item.video.video.urlList[0].url, DownloadFileType.video);
        if(success == true && EHBaseInfo.deviceConst.os == 'ios'){
          EHToast.show('下载成功');
        }
      }
    }
    else {
      EHToast.show('保存出错');
    }
  }

  // ignore: missing_return
  Future<bool> savePlugin(String url, DownloadFileType type) async {
    if(url == "")
      return false;
    bool result = false;
    try{
      result = await EHUtilityPlugin.downloadFile(url, type);
    }catch(e){
      EHLog.info(LogTag.common, 'download fail: ${e}');
    }
    return result;
  }

  void saveImage(UgcItemDetailResp _detail) async {
    List<String> _imageList = _detail.item?.imageList?.map((value) {
      if (value?.urlList != null && value.urlList.length > 0) {
        return value?.urlList[0];
      } else {
        return '';
      }
    })?.toList();
    for(String url in _imageList) {
      if (url != null) {
        if(false == await savePlugin(url, DownloadFileType.image)) {
          EHToast.show('保存出错');
          return;
        }
      }
    }
    if(EHBaseInfo.deviceConst.os == 'ios')
      EHToast.show('下载成功');
  }
}

abstract class _ChildUgcDetail with Store{
  int itemId;
  int childId;

  UgcVideo ugcType; //区分音频和视频
  UgcItemContentType pageType;  //区分图片和视频
  String ugcChannelTag;
  UgcItemChannelType channelType;
  String title;
  bool isTeamOpen = true;
  bool isContentDisplayOpen = true;
  PlaybackState playbackState = PlaybackState.stopped;
  CrossingDetailTracker tracker;
  VideoPlayerController controller;

  @observable
  ObservableFuture<UgcItemDetailResp> fetchDetailFuture; // 详情页面

  @observable
  ObservableFuture<ModifyUgcItemStatusResp> deleteDetailFuture; // 删除动态

  @observable
  bool isLike;

  @observable // 总点赞数
  int itemLikeCount;

  @observable
  bool isOnlySelfVisible; //家长设置孩子动态是否公开

  @computed
  String get bottomWidgetTotalLikeString {
    var totalLikeString = totalLikeCountFormat ?? '0';
    if (totalLikeString.length == 0) {
      totalLikeString = '0';
    }
    return totalLikeString;
  }

  @computed
  String get totalLikeCountFormat {
    if (itemLikeCount == null || itemLikeCount == 0) {
      return '';
    }
    String _likeCount = itemLikeCount?.toString() ?? '';
    if (itemLikeCount == 10000) {
      _likeCount = '1w+';
    } else if (itemLikeCount > 10000) {
      _likeCount = '${(itemLikeCount / 10000).toStringAsFixed(1)}w+';
    }
    return _likeCount;
  }

  @computed // 详情接口请求状态
  UgcDetailState get detailServiceStatus {
    if (deleteDetailFuture?.status == FutureStatus.fulfilled) {
      return UgcDetailState.empty;
    }
    if (fetchDetailFuture?.status == FutureStatus.fulfilled &&
        fetchDetailFuture?.result != null) {
      UgcItemDetailResp _detail = fetchDetailFuture?.result;
      if (_detail?.item?.ugcItemId?.toInt() == 0) {
        return UgcDetailState.error;
      }
      return UgcDetailState.success;
    } else if (fetchDetailFuture?.status == FutureStatus.rejected ||
        (fetchDetailFuture?.status == FutureStatus.fulfilled &&
            fetchDetailFuture?.result == null)) {
      return UgcDetailState.error;
    }
    return UgcDetailState.pending;
  }

  @computed
  bool get hasDetailResults =>
      fetchDetailFuture != null &&
          fetchDetailFuture.status == FutureStatus.fulfilled;

  @action
  ObservableFuture<UgcItemDetailResp> fetchDetail() {
    UgcItemDetailReq _req = UgcItemDetailReq();
    _req.ugcItemId = Int64(itemId);
    _req.appId = 1691;
    _req.childUserId = Int64(childId);
    final future = HUgcService.ugcDetail(_req);
    future.then((UgcItemDetailResp resp) {
      if (resp != null && resp.count != null && resp.interaction != null) {
        itemLikeCount = resp?.count?.likeCount?.toInt() ?? 0;
        isLike = resp?.interaction?.isLike ?? false;

      }
    });
    if(detailServiceStatus != UgcDetailState.success){
      fetchDetailFuture = ObservableFuture(future);
    }
    return fetchDetailFuture;
  }

  @action
  Future<ModifyUgcItemStatusResp> setUgcVisible(UgcItemUserStatus status) async {
    if(fetchDetailFuture?.status == FutureStatus.fulfilled) {
      UgcItemDetailResp _detail = fetchDetailFuture.result;
      ModifyUgcItemStatusReq _req = ModifyUgcItemStatusReq();
      _req.ugcItemId = _detail?.item?.ugcItemId;
      _req.status = status;
      final future = HUgcService.modifyChildUgcItemStatus(_req);
      future.then((ModifyUgcItemStatusResp result) {
        if(result?.baseResp?.error?.code == 0){
          if(status == UgcItemUserStatus.UgcItemUserStatusPUBLIC){
            isOnlySelfVisible = false;
            globalEventBus.publish(ChildUgcDetailEvent(
                UgcDetailEventType.unSelfVisible, _detail?.item?.ugcItemId));
          }
          else{
            isOnlySelfVisible = true;
            globalEventBus.publish(ChildUgcDetailEvent(
                UgcDetailEventType.selfVisible, _detail?.item?.ugcItemId));
          }
        }
      });
      return await future;
    }
    return null;
  }

  @action
  Future<ModifyUgcItemStatusResp> deleteChildDetail() async {
    if (fetchDetailFuture?.status == FutureStatus.fulfilled) {
      UgcItemDetailResp _detail = fetchDetailFuture.result;
      ModifyUgcItemStatusReq _req = ModifyUgcItemStatusReq();
      _req.ugcItemId = _detail?.item?.ugcItemId;
      _req.status = UgcItemUserStatus.UgcItemUserStatusDELETED;
      final future = HUgcService.modifyChildUgcItemStatus(_req);
      future.then((ModifyUgcItemStatusResp result) {
        if (result?.baseResp?.error?.code == 0) {
          globalEventBus.publish(ChildUgcDetailEvent(
              UgcDetailEventType.delete, _detail?.item?.ugcItemId));
          deleteDetailFuture = ObservableFuture(future);
          tracker.itemDeleteSuccess();
          EHRoute.pop();
        } else {
          EHToast.show('删除失败');
        }
      });
      return await future;
    }
    return null;
  }

  void initParam() {
    //初始化埋点相关变量

    playbackState = PlaybackState.stopped;
  }

  // 内部方法
  Future<UgcItemLikeResp> _itemLikeRpc(bool like) async {
    if (fetchDetailFuture?.status == FutureStatus.fulfilled) {
      UgcItemDetailResp _detail = fetchDetailFuture.result;
      UgcItemLikeReq _req = UgcItemLikeReq();
      _req.ugcItemType = 1;
      _req.likeChoice = like == false
          ? UgcItemLikeChoice.UgcItemLikeChoiceLike
          : UgcItemLikeChoice.UgcItemLikeChoiceUnLike;
      _req.ugcItemId = _detail?.item?.ugcItemId;
      final future = HUgcService.ugcItemLike(_req);
      UgcItemLikeResp _result = await future;
      return _result;
    }
    return null;
  }

  @action
  void clickLike() {
    if (!EHAccount.isLogin()) {
      EHAccount.openLogin();
    } else {
      if (isLike) {
        isLike = false;
        itemLikeCount--;
        _itemLikeRpc(true).then((UgcItemLikeResp resp) {
          if (resp != null) {
            UgcItemDetailResp _detail = fetchDetailFuture?.result;
            globalEventBus.publish(ChildUgcDetailEvent(
                UgcDetailEventType.unLike, _detail?.item?.ugcItemId));
          }
        });
      } else {
        isLike = true;
        itemLikeCount++;
        _itemLikeRpc(false).then((UgcItemLikeResp resp) {
          if (resp != null) {
            if (resp != null) {
              UgcItemDetailResp _detail = fetchDetailFuture?.result;
              globalEventBus.publish(ChildUgcDetailEvent(
                  UgcDetailEventType.like, _detail?.item?.ugcItemId));
            }
          }
        });
      }
    }
  }
}
