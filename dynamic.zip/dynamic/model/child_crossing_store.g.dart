// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'child_crossing_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$ChildCrossingStore on _ChildCrossing, Store {
  final _$feedsAtom = Atom(name: '_ChildDynamic.feeds');

  @override
  Feeds get feeds {
    _$feedsAtom.reportRead();
    return super.feeds;
  }

  @override
  set feeds(Feeds value) {
    _$feedsAtom.reportWrite(value, super.feeds, () {
      super.feeds = value;
    });
  }

  final _$childNameAtom = Atom(name: '_ChildDynamic.childName');

  @override
  String get childName {
    _$childNameAtom.reportRead();
    return super.childName;
  }

  @override
  set childName(String value) {
    _$childNameAtom.reportWrite(value, super.childName, () {
      super.childName = value;
    });
  }

  final _$isContentDisplayOpenAtom =
      Atom(name: '_ChildDynamic.isContentDisplayOpen');

  @override
  bool get isContentDisplayOpen {
    _$isContentDisplayOpenAtom.reportRead();
    return super.isContentDisplayOpen;
  }

  @override
  set isContentDisplayOpen(bool value) {
    _$isContentDisplayOpenAtom.reportWrite(value, super.isContentDisplayOpen,
        () {
      super.isContentDisplayOpen = value;
    });
  }

  final _$isTeamOpenAtom = Atom(name: '_ChildDynamic.isTeamOpen');

  @override
  bool get isTeamOpen {
    _$isTeamOpenAtom.reportRead();
    return super.isTeamOpen;
  }

  @override
  set isTeamOpen(bool value) {
    _$isTeamOpenAtom.reportWrite(value, super.isTeamOpen, () {
      super.isTeamOpen = value;
    });
  }

  final _$hasShareAuthorityAtom = Atom(name: '_ChildDynamic.hasShareAuthority');

  @override
  bool get hasShareAuthority {
    _$hasShareAuthorityAtom.reportRead();
    return super.hasShareAuthority;
  }

  @override
  set hasShareAuthority(bool value) {
    _$hasShareAuthorityAtom.reportWrite(value, super.hasShareAuthority, () {
      super.hasShareAuthority = value;
    });
  }

  final _$_refreshDynamicFeedAsyncAction =
      AsyncAction('_ChildDynamic._refreshDynamicFeed');

  @override
  Future<dynamic> _refreshDynamicFeed(int feedId) {
    return _$_refreshDynamicFeedAsyncAction
        .run(() => super._refreshDynamicFeed(feedId));
  }

  final _$deleteDynamicAsyncAction = AsyncAction('_ChildDynamic.deleteDynamic');

  @override
  Future<ModifyUgcItemStatusResp> deleteDynamic(
      Feed feed, ChildCrossingTracker tracker) {
    return _$deleteDynamicAsyncAction
        .run(() => super.deleteDynamic(feed, tracker));
  }

  @override
  String toString() {
    return '''
feeds: ${feeds},
childName: ${childName},
isContentDisplayOpen: ${isContentDisplayOpen},
isTeamOpen: ${isTeamOpen},
hasShareAuthority: ${hasShareAuthority}
    ''';
  }
}
