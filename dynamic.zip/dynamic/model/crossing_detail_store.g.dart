// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crossing_detail_store.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$ChildUgcDetail on _ChildUgcDetail, Store {
  Computed<String> _$bottomWidgetTotalLikeStringComputed;

  @override
  String get bottomWidgetTotalLikeString =>
      (_$bottomWidgetTotalLikeStringComputed ??= Computed<String>(
              () => super.bottomWidgetTotalLikeString,
              name: '_ChildUgcDetail.bottomWidgetTotalLikeString'))
          .value;
  Computed<String> _$totalLikeCountFormatComputed;

  @override
  String get totalLikeCountFormat => (_$totalLikeCountFormatComputed ??=
          Computed<String>(() => super.totalLikeCountFormat,
              name: '_ChildUgcDetail.totalLikeCountFormat'))
      .value;
  Computed<UgcDetailState> _$detailServiceStatusComputed;

  @override
  UgcDetailState get detailServiceStatus => (_$detailServiceStatusComputed ??=
          Computed<UgcDetailState>(() => super.detailServiceStatus,
              name: '_ChildUgcDetail.detailServiceStatus'))
      .value;
  Computed<bool> _$hasDetailResultsComputed;

  @override
  bool get hasDetailResults => (_$hasDetailResultsComputed ??= Computed<bool>(
          () => super.hasDetailResults,
          name: '_ChildUgcDetail.hasDetailResults'))
      .value;

  final _$fetchDetailFutureAtom =
      Atom(name: '_ChildUgcDetail.fetchDetailFuture');

  @override
  ObservableFuture<UgcItemDetailResp> get fetchDetailFuture {
    _$fetchDetailFutureAtom.reportRead();
    return super.fetchDetailFuture;
  }

  @override
  set fetchDetailFuture(ObservableFuture<UgcItemDetailResp> value) {
    _$fetchDetailFutureAtom.reportWrite(value, super.fetchDetailFuture, () {
      super.fetchDetailFuture = value;
    });
  }

  final _$deleteDetailFutureAtom =
      Atom(name: '_ChildUgcDetail.deleteDetailFuture');

  @override
  ObservableFuture<ModifyUgcItemStatusResp> get deleteDetailFuture {
    _$deleteDetailFutureAtom.reportRead();
    return super.deleteDetailFuture;
  }

  @override
  set deleteDetailFuture(ObservableFuture<ModifyUgcItemStatusResp> value) {
    _$deleteDetailFutureAtom.reportWrite(value, super.deleteDetailFuture, () {
      super.deleteDetailFuture = value;
    });
  }

  final _$isLikeAtom = Atom(name: '_ChildUgcDetail.isLike');

  @override
  bool get isLike {
    _$isLikeAtom.reportRead();
    return super.isLike;
  }

  @override
  set isLike(bool value) {
    _$isLikeAtom.reportWrite(value, super.isLike, () {
      super.isLike = value;
    });
  }

  final _$itemLikeCountAtom = Atom(name: '_ChildUgcDetail.itemLikeCount');

  @override
  int get itemLikeCount {
    _$itemLikeCountAtom.reportRead();
    return super.itemLikeCount;
  }

  @override
  set itemLikeCount(int value) {
    _$itemLikeCountAtom.reportWrite(value, super.itemLikeCount, () {
      super.itemLikeCount = value;
    });
  }

  final _$isOnlySelfVisibleAtom =
      Atom(name: '_ChildUgcDetail.isOnlySelfVisible');

  @override
  bool get isOnlySelfVisible {
    _$isOnlySelfVisibleAtom.reportRead();
    return super.isOnlySelfVisible;
  }

  @override
  set isOnlySelfVisible(bool value) {
    _$isOnlySelfVisibleAtom.reportWrite(value, super.isOnlySelfVisible, () {
      super.isOnlySelfVisible = value;
    });
  }

  final _$setUgcVisibleAsyncAction =
      AsyncAction('_ChildUgcDetail.setUgcVisible');

  @override
  Future<ModifyUgcItemStatusResp> setUgcVisible(UgcItemUserStatus status) {
    return _$setUgcVisibleAsyncAction.run(() => super.setUgcVisible(status));
  }

  final _$deleteChildDetailAsyncAction =
      AsyncAction('_ChildUgcDetail.deleteChildDetail');

  @override
  Future<ModifyUgcItemStatusResp> deleteChildDetail() {
    return _$deleteChildDetailAsyncAction.run(() => super.deleteChildDetail());
  }

  final _$_ChildUgcDetailActionController =
      ActionController(name: '_ChildUgcDetail');

  @override
  ObservableFuture<UgcItemDetailResp> fetchDetail() {
    final _$actionInfo = _$_ChildUgcDetailActionController.startAction(
        name: '_ChildUgcDetail.fetchDetail');
    try {
      return super.fetchDetail();
    } finally {
      _$_ChildUgcDetailActionController.endAction(_$actionInfo);
    }
  }

  @override
  void clickLike() {
    final _$actionInfo = _$_ChildUgcDetailActionController.startAction(
        name: '_ChildUgcDetail.clickLike');
    try {
      return super.clickLike();
    } finally {
      _$_ChildUgcDetailActionController.endAction(_$actionInfo);
    }
  }

  @override
  String toString() {
    return '''
fetchDetailFuture: ${fetchDetailFuture},
deleteDetailFuture: ${deleteDetailFuture},
isLike: ${isLike},
itemLikeCount: ${itemLikeCount},
isOnlySelfVisible: ${isOnlySelfVisible},
bottomWidgetTotalLikeString: ${bottomWidgetTotalLikeString},
totalLikeCountFormat: ${totalLikeCountFormat},
detailServiceStatus: ${detailServiceStatus},
hasDetailResults: ${hasDetailResults}
    ''';
  }
}
