import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/common/route_page_key.dart';
import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';
import 'package:eh_parents_flutter_biz/community/feeds/feed.dart';
import 'package:eh_parents_flutter_biz/community/feeds/feeds.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/tracker/child_crossing_tracker.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/child_crossing_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:infrastructure/route/src/eh_route.dart';
import 'package:mobx/mobx.dart';
import 'package:eh_sliver_candybox/eh_sliver_candybox.dart';
part 'child_crossing_store.g.dart';

enum ControllerEventType { teamOpen, teamClose, ContentOpen, ContentClose }

class ChildCrossingStore extends _ChildCrossing with _$ChildCrossingStore{
  ChildCrossingStore({int deviceUserId}){
    this.deviceUserId = deviceUserId;
  }

  Future refreshCrossing(int feedId) async{
    await _refreshDynamicFeed(feedId);
  }

  IndexedWidgetBuilder buildCell() {
    return (context, index){
      final childFeed = Provider.of<ChildCrossingStore>(context).feeds.feeds[index];
      return SliverMultiBoxScrollUpdateListener(
        debounce: 1000,
        child: ChildCrossingCard(feed: childFeed,),
      );
    };
  }

  void toDeviceControl(String deviceUserId) {
    EHRoute.push(
      'hparents://flutter',
      extras: {
        'route': RoutePageKey.DEVICE_CONTROL_CENTER,
        'params': {
          'title': "管控中心",
          'device_user_id': deviceUserId,
        },
      },
    );
  }

  void saveToLocal(Feed feed, ChildCrossingTracker tracker) async{
    this.tracker = tracker;
    if (feed.rawData?.programCell?.item?.contentType == UgcItemContentType.UgcItemContentTypeImageText) {
      saveImage(feed);
    }
    else {
      bool success = await savePlugin(feed.rawData.programCell.item.video.video.urlList[0].url, DownloadFileType.video);
      if(success == true && EHBaseInfo.deviceConst.os == 'ios'){
        EHToast.show('下载成功');
      }
    }
  }

  //下载图片视频
  // ignore: missing_return
  Future<bool> savePlugin(String url, DownloadFileType type) async {
    if(url == "")
      return false;
    bool result = false;
    try{
      result = await EHUtilityPlugin.downloadFile(url, type);
    }catch(e){
      EHLog.info(LogTag.common, 'download fail: ${e}');
    }
    return result;
  }

  void saveImage(Feed feed) async{
    List<String> _imageList = feed.rawData?.programCell?.item?.imageList?.map((value) {
      if (value?.urlList != null && value.urlList.length > 0) {
        return value?.urlList[0];
      } else {
        return '';
      }
    })?.toList();
    for(String url in _imageList) {
      if (url != null) {
        if(false == await savePlugin(url, DownloadFileType.image)) {
          EHToast.show('保存出错');
          return;
        }
      }
    }
    if(EHBaseInfo.deviceConst.os == 'ios')
      EHToast.show('下载成功');
  }

}

abstract class _ChildCrossing with Store{
  int deviceUserId;

  ChildCrossingTracker tracker;
  @observable
  Feeds feeds = Feeds();

  @observable
  String childName = "";

  @observable
  bool isContentDisplayOpen = true;

  @observable
  bool isTeamOpen = true;

  @observable
  bool hasShareAuthority = true;

  bool isPush = false;

  bool isFeedEmpty() {
    return feeds.count == 0;
  }

  bool isFeedRequestError() {
    return feeds.isRequestError;
  }

  @action
  Future _refreshDynamicFeed(int feedId) async{
    await feeds.refreshDynamic(feedId); 
    isContentDisplayOpen = feeds.isContentDisplayOpen;
    isTeamOpen = feeds.isTeamOpen;
    if(!isFeedEmpty()) childName = feeds.feeds[0].rawData.programCell.user.nickName;
  }

  @action
  Future<ModifyUgcItemStatusResp> deleteDynamic(Feed feed, ChildCrossingTracker tracker) async {
      ModifyUgcItemStatusReq _req = ModifyUgcItemStatusReq();
      _req.ugcItemId = feed.ugcItemId;
      _req.status = UgcItemUserStatus.UgcItemUserStatusDELETED;
      final future = HUgcService.modifyChildUgcItemStatus(_req);
      future.then((ModifyUgcItemStatusResp result) {
        if (result?.baseResp?.error?.code == 0) {
          feeds.feeds.removeWhere((item) => item.ugcItemId == feed.ugcItemId);
          tracker.itemDeleteSuccess();
        } else {
          EHToast.show('删除失败');
        }
      });
      return await future;
    }

  bool hasContent() {
    return true;
  }
}