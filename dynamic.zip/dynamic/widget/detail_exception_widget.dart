
import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/crossing_detail_store.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DetailError extends StatelessWidget {
  final int ugcItemId;
  const DetailError({Key key, this.ugcItemId}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final detailStore = Provider.of<ChildUgcDetail>(context);
    return Scaffold(
        appBar: EHAppBar(
          style: EHAppBarContentStyle.dark,
        ),
        body: Container(
          child: EHErrorWidget(onPressReload: () {
            detailStore.fetchDetail();
            }
          ),
        ));
  }
}

class DetailEmptyWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: EHAppBar(
        style: EHAppBarContentStyle.dark,
      ),
      body: Container(
        child: EHEmptyWidget(),
      ),
    );
  }
}