import 'dart:io';

import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:flutter/material.dart';

class UgcImageSlider extends StatefulWidget {
  final List imageList;
  final double indicatorHeight;
  final BuildContext context;
  UgcImageSlider({
    Key key,
    this.context,
    this.imageList,
    this.indicatorHeight = 13,
  }) : super(key: key);

  @override
  _UgcImageSliderState createState() => _UgcImageSliderState();
}

class _UgcImageSliderState extends State<UgcImageSlider> {
  int _curIndex = 0;

  @override
  Widget build(BuildContext context) {
    List<Widget> _list = [
      _buildPageView(context),
      Positioned(
        top: 50+EHBaseInfo.deviceConst.inset_top,
        right: 20,
        child: PageIndicator(
          imageList: widget.imageList,
          curIndex: _curIndex,
        ),
      ),
    ];
    if (widget.imageList != null && widget.imageList.length > 1) {
      _list.add(Positioned(
        bottom: widget.indicatorHeight+EHBaseInfo.deviceConst.inset_bottom,
        child: Indicator(
          imageList: widget.imageList,
          curIndex: _curIndex,
        ),
      ));
    }

    return Stack(
      alignment: Alignment.center,
      children: _list,
    );
  }

  Widget _buildPageView(BuildContext context) {
    return PageView.builder(
      onPageChanged: (index) {
        setState(() {
          _curIndex = index;
        });
      },
      itemBuilder: (context, index) {
        return EHImage.network(
          widget.imageList[index],
          fit: BoxFit.fitWidth,
        );
      },
      itemCount: widget.imageList.length,
      physics:
      const BouncingScrollPhysics(parent: const ClampingScrollPhysics()),
    );
  }
}

class Indicator extends StatelessWidget {
  final List imageList;
  final int curIndex;
  const Indicator({Key key, this.imageList, this.curIndex}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<Widget> _list = imageList.map((s) {
      int size = s == imageList[curIndex % imageList.length] ? 6:4;
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3.0),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: size == 6 ? Color(0Xff4CADFF) : Color(0X99FFFFFF),
            borderRadius: BorderRadius.circular(size/2),
          ),
          child: SizedBox(
            width: size.toDouble(),
            height: size.toDouble(),
          ),
        ),
      );
    }).toList();
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: _list,
      ),
    );
  }
}

class PageIndicator extends StatelessWidget {
  final List imageList;
  final int curIndex;
  const PageIndicator({Key key, this.imageList, this.curIndex})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    if (imageList != null && imageList.length > 1) {
      return Container(
        height: 24,
        width: 38,
        padding: EdgeInsets.only(
            left: 8, right: 8, top: 2, bottom: 2),
        alignment: Alignment.center,
        child: Container(
          child: Text(
            '${curIndex + 1}/${imageList?.length}',
            style: TextStyle(fontSize: 10, color: Color(0XFFFFFFFF)),
          ),
        ),
        decoration: BoxDecoration(
          color: Color(0X99000000),
          borderRadius: BorderRadius.all(Radius.circular(9.0)),
        ),
      );
    } else {
      return Container();
    }
  }
}
