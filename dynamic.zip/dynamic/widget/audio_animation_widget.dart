import 'dart:ui';

import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:flutter/cupertino.dart';

class AudioAnimation extends StatefulWidget {
  AudioAnimation({this.width = 64});
  final double width;
  @override
  _AudioAnimationState createState() => _AudioAnimationState();
}

class _AudioAnimationState extends State<AudioAnimation> with SingleTickerProviderStateMixin{
  AnimationController animationController;
  @override
  void initState(){
    super.initState();
    animationController = AnimationController(
      duration: Duration(milliseconds: 2500),
      vsync: this,
    );
    animationController.addStatusListener(animationStatusListener);
    animationController.forward();
  }

  void animationStatusListener(AnimationStatus status){
    if(status == AnimationStatus.completed || status == AnimationStatus.dismissed){
      animationController.repeat();
    }
  }
  @override
  void dispose(){
    animationController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    double size = widget.width*1.7;
    return Container(
      child: AnimatedBuilder(
        animation: animationController,
        builder: (BuildContext context, Widget child){
          return CustomPaint(
            size: Size(size, size),
            willChange: false,
            painter: Painter(
              inRadiusProportion: animationController.value,
              size: size),
          );
        },
      ),
    );
  }
}

class Painter extends CustomPainter{
  final double inRadiusProportion;
  final double size;
  Painter({this.inRadiusProportion, this.size}){
   outRadius = size/2;
   inRadius = ((0.4*inRadiusProportion+1.3)/1.7)*outRadius;
   midRadius = ((0.4*((inRadiusProportion<0.5 ? 0.5 : -0.5)+inRadiusProportion)+1.3)/1.7)*outRadius;
  }
  double outRadius;
  double midRadius;
  double inRadius;

  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint()
    ..isAntiAlias = true
    ..style = PaintingStyle.stroke
    ..strokeWidth = 2.0
    ..color = Color(0xFFFFFF+(ehIntParse(127-inRadiusProportion*127) << 24));
    canvas.drawCircle(Offset(size.width/2,size.width/2), outRadius, paint);
    paint.color = Color(0xFFFFFF+(ehIntParse(255-inRadiusProportion*127) << 24));
    canvas.drawCircle(Offset(size.width/2,size.width/2), inRadius, paint);
    paint.color = Color(0xFFFFFF+(ehIntParse(255-((inRadiusProportion<0.5 ? 0.5 : -0.5)+inRadiusProportion)*127) << 24));
    canvas.drawCircle(Offset(size.width/2,size.width/2), midRadius, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }

}

class AudioChild extends StatelessWidget{
  final double size;
  AudioChild({this.size = 64});
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: <Widget>[
        DecoratedBox(
          child: SizedBox(
            width: size,
            height: size,
          ),
          decoration: BoxDecoration(
            color: EHColors.white,
            borderRadius: BorderRadius.circular(size/2),
          ),
        ),
        EHImage.asset(
          'assets/images/lamp/lamp_icon_audio_stop.png',
          width: 2*size/3,
          height: 2*size/3,
          fit: BoxFit.fitWidth,
        ),
      ],
    );
  }
}