import 'dart:math';

import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/crossing_detail_store.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/tracker/crossing_detail_tracker.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/audio_animation_widget.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/detail_info_card.dart';
import 'package:eh_video_player/eh_video_player.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';

class FeedPlayCard extends StatefulWidget {
  FeedPlayCard({Key key, this.controller, this.cover})
      : super(key: key);

  final VideoPlayerController controller;
  final String cover;

  @override
  _FeedPlayCardState createState() => _FeedPlayCardState();
}

class _FeedPlayCardState extends State<FeedPlayCard> {
  @override
  void initState() {
    initController();
    super.initState();
  }

  Future<void> initController() async {
    widget.controller.addListener(() {
      setState(() {});
      CrossingDetailTracker tracker = Provider.of<CrossingDetailTracker>(context);
      if(_hidePlayButton == false && tracker.hasPlayed && widget.controller.value.playbackState == PlaybackState.stopped) {
        tracker.over_cnt++;
        tracker.hasPlayed = false;
      }
      if(widget.controller.value.playbackState == PlaybackState.playing && tracker.hasPlayed == false){
        tracker.hasPlayed = true;
      }
    });
    await widget.controller.initialize();
    widget.controller.play();
  }

  @override
  void dispose() {
    widget.controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final detailStore = Provider.of<ChildUgcDetail>(context);
    final _controller = widget.controller;
    final List<Widget> _list = [
      BackgroundVideo(
        controller: _controller,
        videoPlayingOrStopped: _videoPlayingOrStopped,
      ),
      PlayButton(hidePlayButton: _hidePlayButton, controller: _controller),
      UgcLike(videoPlayingOrStopped: _videoPlayingOrStopped)
    ];

    if(!detailStore.ugcType.hasVideo()){
      _list.addAll([
        Visibility(
          visible: _hidePlayButton,
          child: GestureDetector(
            onTap: () {
              _controller.pause();
            },
            child: Stack(
              alignment: Alignment.center,
              children: <Widget>[
                AudioChild(size: 82,),
                AudioAnimation(width: 82,)
              ],
            ),
          )
        ),
      ]);
    }

    return ClipRRect(
      child: Container(
        child: Stack(
          fit: StackFit.loose,
          alignment: Alignment.center,
          children: _list,
        ),
      ),
    );
  }

  bool get _hidePlayButton =>
      widget.controller.value.playbackState == PlaybackState.playing;

  bool get _videoPlayingOrStopped =>
      widget.controller.value.playbackState == PlaybackState.playing ||
          widget.controller.value.playbackState == PlaybackState.stopped;
}

class PlayButton extends StatelessWidget {
  const PlayButton({
    Key key,
    @required bool hidePlayButton,
    @required this.controller,
  })  : _hidePlayButton = hidePlayButton,
        super(key: key);

  final bool _hidePlayButton;
  final VideoPlayerController controller;
  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: !_hidePlayButton,
      child: Center(
        child: GestureDetector(
          onTap: () {
            controller.play();
          },
          child: EHImage.asset(
            "assets/images/lamp/lamp_icon_video_play.png",
            width: 64,
            height: 64,
          ),
        ),
      ),
    );
  }
}

class BackgroundVideo extends StatelessWidget {
  const BackgroundVideo({
    Key key,
    @required this.controller,
    @required this.videoPlayingOrStopped,
  }) : super(key: key);

  final VideoPlayerController controller;
  final bool videoPlayingOrStopped;

  @override
  Widget build(BuildContext context) {
    final detailStore = Provider?.of<ChildUgcDetail>(context);
    final UgcItemDetailResp _result = detailStore?.fetchDetailFuture?.result;
    final _cover = _result.item.coverImage?.urlList?.firstSafely ?? null;
    Widget cover;
    if(detailStore.ugcType.hasCover()){
      cover = _cover == null
          ? Container(
        color: Colors.black,
      )
          : LayoutBuilder(
        builder: (context, contraint) {
          return EHImage.network(
            _cover,
            decoration: BoxDecoration(color: Colors.black),
            width: contraint.maxWidth,
            height: contraint.maxHeight,
            fit: BoxFit.fitWidth,
          );
        }
      );
    }
    else if(!detailStore.ugcType.hasVideo()){
      cover = LayoutBuilder(
        builder:(context, constraint){
          return Container(
            color: EHColors.blue,
            child: EHImage.asset(
              "assets/images/lamp/lamp_audio_ugc_bg.png",
              width: constraint.maxWidth,
              height: constraint.maxHeight,
              fit: BoxFit.cover,
            )
          );
        },
      );
    }
    else {
      cover = Container(
        color: Colors.black,
      );
    }

    List<Widget> _child = [
      VideoPlayer(
        controller,
        placeHolderChild: cover,
      ),
    ];
    if(!detailStore.ugcType.hasVideo()){
      _child.add(cover);
    }
    _child.addAll([
      UgcInfoText(
        videoPlayingOrStopped: videoPlayingOrStopped,
      ),

      Positioned(
        bottom: 0,
        left: 0,
        width: EHBaseInfo.deviceConst.screen_width.toDouble(),
        child: Offstage(
            offstage: !videoPlayingOrStopped,
            child: VideoProgressIndicator(
              controller,
              height: 2,
              style: VideoProgressBarStyle.defaultDraggableStyle,
            )),
      ),
      Positioned(
        bottom: 24,
        right: 20,
        child: Offstage(
            offstage: videoPlayingOrStopped,
            child: VideoProgressText(controller)),
      ),
      Positioned(
        bottom: 32,
        left: 0,
        child: Offstage(
            offstage: videoPlayingOrStopped,
            child: DraggableVideoProgressBar(
              controller,
              onPercentageChanged: (percentage) {},
              onPanChanged: (percentage, onPanChanged) {},
              width: EHBaseInfo.deviceConst.screen_width.toDouble(),
              style: VideoProgressBarStyle.defaultDraggableStyle,
            )),
      ),
    ]);

    return GestureDetector(
      onTap: () {
        if (controller.value.playbackState == PlaybackState.playing) {
          controller.pause();
        } else {
          controller.play();
        }
      },
      child: Stack(
        fit: StackFit.loose,
        alignment: Alignment.bottomLeft,
        children: _child,
      ),
    );
  }
}