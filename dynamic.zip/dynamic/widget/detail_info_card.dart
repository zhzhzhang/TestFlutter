import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/crossing_detail_store.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/tracker/crossing_detail_tracker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class UgcInfoText extends StatelessWidget {
  const UgcInfoText({
    Key key,
    @required this.videoPlayingOrStopped,
  }) : super(key: key);

  final bool videoPlayingOrStopped;
  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 28,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Visibility(
          visible: videoPlayingOrStopped,
          child: _BuildContent(context),
        ),
      )
    );
  }

  Widget _BuildContent(BuildContext context){
    final ChildUgcDetail detailStore = Provider.of<ChildUgcDetail>(context);
    Color tagColor;
    switch(detailStore.channelType){
      case UgcItemChannelType.UgcItemTypeProgramSTU:
        tagColor = EHColors.green;
        break;
      case UgcItemChannelType.UgcItemTypeTeamSTU:
        tagColor = EHColors.blue;
        break;
      default:
        tagColor = EHColors.blueBlack;
    }
    List<Widget> _list = [];
    _list.add(
      DecoratedBox(
        decoration: BoxDecoration(
            color: tagColor,
            borderRadius: BorderRadius.all(Radius.circular(6))
        ),
        child: Padding(
          padding: EdgeInsets.only(left: 5, right: 5, top: 4, bottom: 4),
          child: Text(
          detailStore.ugcChannelTag,
          style: TextStyle(
            fontSize: 12,
            color: EHColors.white,
          ),
        ),
      ),
    ));
    _list.add(SizedBox(width: 6,));
    _list.add(Observer(
      builder: (BuildContext context) {
        return Visibility(
          visible: detailStore.isOnlySelfVisible,
          child: DecoratedBox(
              decoration: BoxDecoration(
                  color: EHColors.black_3,
                  borderRadius: BorderRadius.all(Radius.circular(6))
              ),
              child: Padding(
                padding: EdgeInsets.only(left: 5, right: 5, top: 4, bottom: 4),
                child: Text(
                  "仅自己可见",
                  style: TextStyle(
                    fontSize: 12,
                    color: EHColors.white,
                  ),
                ),
              )
          ),
        );
      },
    ));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget>[
        Row(
          children: _list,
        ),
        SizedBox(height: 4,),
        Text(
          detailStore.title,
          maxLines: 2,
          style: TextStyle(
            color: EHColors.white,
            fontSize: 18,
          ),
        ),
      ],
    );
  }
}

class UgcLike extends StatelessWidget {
  final GestureTapCallback likeAction;
  final bool videoPlayingOrStopped;
  const UgcLike({
    Key key,
    this.likeAction,
    @required this.videoPlayingOrStopped,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final detailStore = Provider?.of<ChildUgcDetail>(context);
    final _tracker = Provider?.of<CrossingDetailTracker>(context);
    return Visibility(
        visible: videoPlayingOrStopped,
        child: Positioned(
            bottom: 177+EHBaseInfo.deviceConst.inset_bottom,
            right: 23,
            child: Observer(builder: (_) {
              return Column(children: [
                GestureDetector(
                  onTap: () {
                    if (likeAction != null) {
                      likeAction();
                    }
                    _tracker?.itemLike(detailStore?.isLike);
                    detailStore?.clickLike();
                  },
                  child: EHImage.asset(
                    detailStore?.isLike == true
                        ? 'assets/images/lamp/lamp_icon_like_highlight.png'
                        : 'assets/images/lamp/lamp_icon_like_white.png',
                    width: 44,
                    height: 44,
                  ),
                ),
                SizedBox(height: 7,),
                Text(
                  detailStore?.itemLikeCount == 0 ?  '赞' : detailStore?.itemLikeCount.toString(),
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16),
                ),
              ]);
            })));
  }
}
