import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';
import 'package:eh_parents_flutter_biz/community/feeds/feed.dart';
import 'package:eh_parents_flutter_biz/community/ugc_detail/state/ugc_detail.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/child_crossing_store.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/crossing_detail_store.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/tracker/child_crossing_tracker.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/audio_animation_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class ChildCrossingCard extends StatelessObserverWidget {
  ChildCrossingCard({Key key, this.feed}) : super(key: key);
  final Feed feed;
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.all(Radius.circular(8)),
      child: Container(
        color: EHColors.color_e6ffffff,
        child: Column(
          children: [
            _feedImage(feed: feed),
            _feedInfo(feed: feed),
          ],
        ),
      ),
    );
  }
}

class _feedImage extends StatelessObserverWidget {
  _feedImage({Key key, this.feed}) : super(key: key);
  final Feed feed;

  @override
  Widget build(BuildContext context) {
    final ChildCrossingStore store = Provider.of<ChildCrossingStore>(context);
    return GestureDetector(
      onTap: () {
        _toDetailPage(store);
        EHTracker.onEvent('hardware_content_square_conten_click',
            context: context);
      }, //注册响应函数，而不是函数调用，不然会直接调用
      child: ClipRRect(
        borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
        child: Stack(alignment: Alignment.center, children: [
          _CoverBackground(feed: feed),
          _CoverText(feed: feed),
          _CoverVideoButton(feed: feed),
        ]),
      ),
    );
  }

  void _toDetailPage(ChildCrossingStore store) {
    // hparents://flutter?route=ugc_detail_page&hide_navigation_bar=1&ugcItemId=12345&page=image&anchor= comment
    EHRoute.push("hparents://flutter", extras: {
      "route": RoutePageKey.KIDS_CROSSING_DETAIL,
      "params": {
        "ugcItemId": feed.ugcItemId.toString() ?? 0,
        "deviceUserId": store.deviceUserId.toString() ?? 0,
        "isContentDisplayOpen": store.isContentDisplayOpen,
        "isOnlySelfVisible": feed.isOnlySelfVisible,
        "isTeamOpen": store.isTeamOpen
      }
    });
  }
}

class _CoverBackground extends StatelessObserverWidget {
  _CoverBackground({this.feed});
  final Feed feed;

  @override
  Widget build(BuildContext context) {
    Widget bgChild;
    if (feed.contentType == UgcItemContentType.UgcItemContentTypeImageText ||
        feed.contentType == UgcItemContentType.UgcItemContentTypeVideo) {
      bgChild = AspectRatio(
        aspectRatio: 1.7,
        child: EHImage.network(
            //不显示网络图片，url正确！！网络环境问题
            feed.coverURL,
            fit: BoxFit.cover,
            placeHolder: DecoratedBox(
              decoration: BoxDecoration(color: Color(0x80EFEFEF)),
              child: Padding(
                padding: EdgeInsets.only(left: 137, right: 136, top: 71, bottom: 72),
                child: EHImage.asset(
                  "assets/images/common/icon_default_image.png",
                ),
              ),
            )),
      );
    } else {
      bgChild = Stack(alignment: Alignment.center, children: <Widget>[
        AspectRatio(
          aspectRatio: 1.7,
          child: Container(
            color: EHColors.blue,
          ),
        ),
        AudioChild(
          size: 64,
        ),
        //AudioAnimation(width: 64),
      ]);
    }
    return bgChild;
  }
}

class _CoverText extends StatelessObserverWidget {
  _CoverText({this.feed});
  final Feed feed;

  @override
  Widget build(BuildContext context) {
    String tagText = feed.rawData.programCell.item.channelExt.channelTag ?? "孩子发布的动态";
    UgcItemChannelType channelType = feed.rawData.programCell.item.channelType;
    Color tagColor;
    if (UgcItemChannelType.UgcItemTypeProgramSTU == channelType)
      tagColor = EHColors.green;
    else if (UgcItemChannelType.UgcItemTypeTeamSTU == channelType)
      tagColor = EHColors.blue;
    else
      tagColor = EHColors.blueBlack;
    return Positioned(
        left: 0,
        top: 0,
        child: DecoratedBox(
            decoration: BoxDecoration(
              color: tagColor,
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(8.0),
                  topLeft: Radius.circular(8.0)),
            ),
            child: Padding(
              padding: EdgeInsets.only(top: 4, left: 6, right: 6, bottom: 3),
              child: Text(
                tagText,
                style: TextStyle(
                  fontSize: 12,
                  color: EHColors.white,
                ),
              ),
            )));
  }
}

class _CoverVideoButton extends StatelessObserverWidget {
  _CoverVideoButton({this.feed});
  final Feed feed;

  @override
  Widget build(BuildContext context) {
    if (feed.contentType != UgcItemContentType.UgcItemContentTypeImageText) {
      return Positioned(
          bottom: 11,
          right: 11,
          height: 40,
          width: 40,
          child: EHImage.asset('assets/images/lamp/lamp_icon_video_play.png'));
    } else {
      return Container(
        width: 0.0,
        height: 0.0,
      );
    }
  }
}

// ignore: must_be_immutable
class _feedInfo extends StatelessObserverWidget {
  final Feed feed;
  ChildCrossingTracker tracker;
  _feedInfo({Key key, this.feed}) : super(key: key);
  String tagText;
  UgcItemChannelType channelType;

  @override
  Widget build(BuildContext context) {
    String lessonName;
    tagText = feed.rawData.programCell.item.channelExt.channelTag ?? "孩子发布的动态";
    channelType = feed.rawData.programCell.item.channelType;
    if (UgcItemChannelType.UgcItemTypeProgramSTU == channelType) //一起学
      lessonName = feed.rawData.programCell.lesson.name;
    else if (UgcItemChannelType.UgcItemTypeTeamSTU == channelType) //组队学习
      lessonName = feed.rawData.programCell.item.title;
    else
      lessonName = feed.rawData.programCell.item.text;
    tracker = ChildCrossingTracker(context, feed, lessonName);

    return Container(
        padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 16),
        color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Visibility (
              visible: ehStringIsNotEmpty(lessonName),
              child: Text(
                lessonName,
                maxLines: 2,
                style: TextStyle(
                  fontSize: 18,
                  color: EHColors.black,
                ),
              ),
            ),
            SizedBox(
              height: 8,
            ),
            _buildOtherInfo(context),
          ],
        ),
    );
  }

  Widget _buildOtherInfo(BuildContext context) {
    final List<Widget> widgets = [];
    widgets.add(Expanded(
        flex: 1,
        child: Row(
          children: <Widget>[
            _buildDateLabel(feed.rawData.programCell.item.publishTime.toInt()),
            SizedBox(
              width: 5,
            ),
            Observer(
              builder: (_) {
                return Visibility(
                  visible: feed.isOnlySelfVisible,
                  child: Text(
                    "仅自己可见",
                    style: TextStyle(
                      fontSize: 11,
                      color: Color(0Xff999999),
                    ),
                  ),
                );
              },
            )
          ],
        )));
    //添加我喜欢按钮
    widgets.add(_likeInfo(
      feed: feed,
      tracker: tracker,
    ));
    //添加菜单按钮
    widgets.add(SizedBox(width: 24,));
    widgets.add(GestureDetector(
        onTap: () {
          return _actionSheet(context, feed);
        },
        child: EHImage.asset(
          'assets/images/lamp/lamp_icon_more_gray.png',
          width: 24,
          height: 24,
        )));
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: widgets,
    );
  }

  Widget _buildDateLabel(int timestamp) {
    var date = new DateTime.fromMillisecondsSinceEpoch(timestamp * 1000);
    String formatter = formatDate(
        date ?? DateTime.now(), [yyyy, ".", mm, ".", dd], LocaleType.en);
    return Text(
      formatter,
      style: TextStyle(fontSize: 11, color: Color(0Xff999999)),
    );
  }

  void _actionSheet(BuildContext context, Feed feed) {
    final ChildCrossingStore store = Provider.of<ChildCrossingStore>(context);
    List<String> action = _actionButton(feed);
    int rows = action.length;
    EHActionSheet.show(_actionButton(feed), '取消', (int index) {
      if (index == rows - 1) {
        tracker.itemDeleteClick();
        EHDialog.show(
            title: '删除作业',
            message: '动态不会占用手机储存。如果删除会导致孩子也不可再看到该动态内容，是否确定删除？',
            leftText: '取消',
            rightText: '删除',
            rightAction: () {
              store.deleteDynamic(feed, tracker);
            });
      } else if (index == rows - 2) {
        tracker.itemSetVisibleClick(feed.isOnlySelfVisible);
        final UgcItemUserStatus status = feed.isOnlySelfVisible
            ? UgcItemUserStatus.UgcItemUserStatusPUBLIC
            : UgcItemUserStatus.UgcItemUserStatusPRIVATE;
        if (status == UgcItemUserStatus.UgcItemUserStatusPUBLIC) {
          if (tagText == "组队学习" && !store.feeds.isTeamOpen) {
            EHToast.show("组队权限未开启");
            return;
          } else if (tagText != "组队学习" && !store.feeds.isContentDisplayOpen) {
            EHToast.show("分享权限未开启");
            return;
          }
        }
        feed.setUgcVisible(status);
        EHToast.show(feed.isOnlySelfVisible == true ? "已公开" : "已设为仅家长和孩子可见");
      } else if (rows > 2 && index == rows - 3) {
        tracker.itemDownloadClick();
        store.saveToLocal(feed, tracker);
      }
      ;
    });
  }

  List<String> _actionButton(Feed feed) {
    List<String> _list = [];
    if (feed?.contentType == UgcItemContentType.UgcItemContentTypeImageText ||
        feed.rawData.programCell.item.video.hasVideo()) _list.add("保存到相册");
    _list.add(feed.isOnlySelfVisible ? "设为公开" : "设为私密");
    _list.add("删除");
    return _list;
  }
}

class _likeInfo extends StatelessObserverWidget {
  final Feed feed;
  final ChildCrossingTracker tracker;
  _likeInfo({this.feed, this.tracker});

  @override
  Widget build(BuildContext context) {
    return Observer(builder: (context) {
      final int _likeCount = feed.likeCount == null ? 0 : feed.likeCount;
      //接受详情页返回的更新事件
      globalEventBus.respond<ChildUgcDetailEvent>((event) {
        if (event?.itemId != null && event?.itemId == feed?.ugcItemId) {
          switch (event?.type) {
            case UgcDetailEventType.unSelfVisible:
              feed.isOnlySelfVisible = false;
              break;
            case UgcDetailEventType.selfVisible:
              feed.isOnlySelfVisible = true;
              break;
            case UgcDetailEventType.like:
              feed.liked = true;
              feed.likeCount = _likeCount + 1;
              break;
            case UgcDetailEventType.unLike:
              feed.liked = false;
              feed.likeCount = _likeCount - 1;
              break;
            default:
              break;
          }
        }
      }); //
      return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          width: 24,
          height: 24,
          child: GestureDetector(
            onTap: _onTapLike(context),
            child: EHImage.asset(
              'assets/images/lamp/lamp_icon_like${feed.liked ? "_highlight" : ""}.png',
              fit: BoxFit.fitHeight,
            ),
          ),
        ),
        SizedBox(
          width: 3.5,
        ),
        Text(
          _likeCount == 0 ? '赞' : _likeCount.toString(),
          style: TextStyle(
            fontSize: 11,
            color: EHColors.color_ccc,
          ),
        ),
      ]);
    });
  }

  GestureTapCallback _onTapLike(BuildContext context) {
    return () {
      tracker.itemLike(feed.liked);
      if (feed.feedTag != FeedTag.draft && feed.feedTag != FeedTag.publishing) {
        like(context);
      }
    };
  }

  void like(BuildContext context) {
      UgcItemLikeReq req = UgcItemLikeReq();
      req.ugcItemType = 1;
      req.ugcItemId = feed.ugcItemId;

      if (feed.liked) {
        feed.likeCount -= 1;
        feed.liked = false;
        req.likeChoice = UgcItemLikeChoice.UgcItemLikeChoiceUnLike;
      } else {
        feed.likeCount += 1;
        feed.liked = true;
        req.likeChoice = UgcItemLikeChoice.UgcItemLikeChoiceLike;
      }
      HUgcService.ugcItemLike(req);
  }
}
