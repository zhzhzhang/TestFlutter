import 'package:eh_parents_flutter_biz/lamp/dynamic/model/crossing_detail_store.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/detail_body_card.dart';
import 'package:eh_video_player/eh_video_player.dart';
import 'package:flutter/material.dart';
import 'package:eh_parents_flutter_biz/common/rpc_imports.dart';
import '../../../common/commonimports.dart';

class UgcFeedWidget extends StatelessWidget {
  final VideoPlayerController controller = VideoPlayerController();
  UgcFeedWidget({Key key}) : super(key: key);

  play() {
    if (controller.textureCreated &&
        controller.value.playbackState == PlaybackState.paused) {
      controller.play();
    }
  }

  pause() {
    if (controller.textureCreated &&
        controller.value.playbackState == PlaybackState.playing) {
      controller.pause();
    }
  }

  @override
  Widget build(BuildContext context) {
    controller.dataSourceType = VideoPlayerDataSourceType.videoModel;

    final detailStore = Provider?.of<ChildUgcDetail>(context);
    detailStore.controller = controller;
    if (detailStore.hasDetailResults) {
      final UgcItemDetailResp _result = detailStore.fetchDetailFuture.result;
      if (_result.item != null && _result.item.video != null) {
        if(_result.item.video.hasVideo())
          controller.dataSource = _result.item?.video?.video?.videoModel;
        else{
          List<String> source = _result.item?.video?.audio?.urlList;
          controller.dataSource = source.isNotEmpty ? source[0]:"";
          controller.dataSourceType = VideoPlayerDataSourceType.network;
        }
        return Container(
              child: FeedPlayCard(
                controller: controller,
              ),
            );
      }
    }
    return Container();
  }
}
