import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/lamp/common/lamp_const.dart';
import 'package:flutter/cupertino.dart';
import 'package:infrastructure/image/image.dart';
import 'package:infrastructure/theme/src/eh_colors.dart';
import 'package:eh_parents_flutter_biz/lamp/common/widget_extentions.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/child_crossing_store.dart';


class PageHeader extends StatelessWidget{
  final int deviceUserId;
  PageHeader({this.deviceUserId});
  @override
  Widget build(BuildContext context) {
    final store = Provider.of<ChildCrossingStore>(context, listen: false);
    return Observer(
        builder: (context) {
          if (store.isContentDisplayOpen)
            return SizedBox(height: 20,);
          else{
            String text1;
            String text2;
            if(store.isTeamOpen) {
              text1 = "仅开启了组队学习分享";
              text2 = "开启其他分享";
            }
            else {
              text1 = "当前孩子无法做内容分享";
              text2 = "去开启";
            }
            return Row(
              children: <Widget>[
                Text(
                  text1,
                  style: TextStyle(color: EHColors.color_4cadff, fontSize: 14),
                ),
                Spacer(),
                Text(
                  text2,
                  style: TextStyle(color: EHColors.color_4cadff, fontSize: 14),
                ),
                EHImage.asset(
                  'assets/images/lamp/lamp_icon_right_arrow_blue.png',
                  height: 10,
                )
              ],
            )
                .paddings(EdgeInsets.symmetric(horizontal: 20, vertical: 10))
                .background(
                color: LampConst.color_e2f1ff,
                borderRadius: BorderRadius.circular(20))
                .tap(() {
                  {
                    store.toDeviceControl(deviceUserId.toString());
                    EHTracker.onEvent('hardware_content_square_control_click', context: context);
                  }
                })
                .paddings(
                EdgeInsets.only(left: 20, right: 20, bottom: 16, top: 16));
          }});
  }
}
