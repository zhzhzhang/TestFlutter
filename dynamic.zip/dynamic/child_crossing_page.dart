import 'package:eh_parents_flutter_biz/common/commonimports.dart';
import 'package:eh_parents_flutter_biz/community/program/publish_hint_store.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/model/child_crossing_store.dart';
import 'package:eh_parents_flutter_biz/lamp/dynamic/widget/crossing_page_header.dart';
import 'package:eh_sliver_candybox/eh_sliver_candybox.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_event_bus/flutter_event_bus.dart';

class ChildCrossingPage extends EHBasePage {
  ChildCrossingPage(routeParams) : super(routeParams);

  @override
  State<StatefulWidget> createState() {
    return _ChildCrossingPageState();
  }
}

class _ChildCrossingPageState extends EHBasePageState<ChildCrossingPage> {
  final ChildCrossingStore store = ChildCrossingStore();
  Subscription _controllerChangeSubscription;
  final publishHintStore = PublishHintStore();
  var isFirstRefresh = true;
  @override
  void dispose() {
    _controllerChangeSubscription?.dispose();
    super.dispose();
  }

  @override
  void onAppear() {
    super.onAppear();
    EHTracker.onEvent('page_enter', context: context);
  }

  @override
  void onDisappear() {
    store.feeds.clearCheckPoint(context);
    super.onDisappear();
  }

  @override
  void initState() {
    super.initState();
    store.deviceUserId =
        ehIntParse(paramForKey('device_user_id'), defaultInt: 0);
    _controllerChangeSubscription =
        globalEventBus.respond<ControllerEventType>((event) {
      switch (event) {
        case ControllerEventType.teamOpen:
          store.isTeamOpen = true;
          break;
        case ControllerEventType.teamClose:
          store.isTeamOpen = false;
          break;
        case ControllerEventType.ContentOpen:
          store.isContentDisplayOpen = true;
          break;
        case ControllerEventType.ContentClose:
          store.isContentDisplayOpen = false;
          break;
      }
    });
  }

  Future refreshDynamic() {
    return store.refreshCrossing(store.deviceUserId);
  }

  @override
  Widget build(BuildContext context) {
    return EHPageScaffold(
      connectivity: false,
      future: refreshDynamic,
      errorCheck: () {
        return store.feeds.isRequestError;
      },
      emptyCheck: () {
        return store.isFeedEmpty();
      },
      empty: (context) {
        return EHScaffold(
          appBar: EHAppBar(),
          color: EHColors.color_F8F8F8,
          body: EHEmptyWidget(
            hintText: '暂时还没有动态',
          ),
          isExtend: true,
        );
      },
      success: _buildSuccess,
    );
  }

  Widget _buildSuccess(BuildContext context) {
    return EHScaffold(
        color: EHColors.color_F8F8F8,
        appBar: EHAppBar(
          title: EHAppBarTitle(
            text: store.childName == "" ? "" : "${store.childName}的动态",
          ),
          left: EHAppBarLeft(
            child: EHAppBarIconButton(
              iconPath: EHUikit.getPathForInfraImage('app_bar_back_dark.png'),
              iconHeight: 20,
              iconWidth: 20,
              onPressed: () {
                FocusScope.of(context).requestFocus(FocusNode());
                EHRoute.pop();
              },
            ),
            leftMargin: kEHAppbarLeftMarginTypeBack
          ),
        ),
        //isExtend: true,
        body: Provider(
          create: (context) => store,
          child: RefreshIndicator(
            onRefresh: () {
              return store.refreshCrossing(store.deviceUserId);
            },
            child: ScrollViewListener(
              child: EnhancedScrollView(
                  physics: ClampingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics()),
                  cacheExtent: 1200,
                  slivers: [
                    SliverToBoxAdapter(
                      child: PageHeader(
                        deviceUserId: store.deviceUserId,
                      ),
                    ),
                    feedDynamic(),
                    _LoadMore(
                      feedId: store.deviceUserId,
                      store: store,
                    )
                  ]),
            ),
          ),
        ));
  }

  Widget feedDynamic() {
    return Observer(
      builder: (context) {
        return SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverWaterfallWidget(
            delegate: SliverChildBuilderDelegate(
              store.buildCell(),
              childCount: store.feeds.count,
            ),
            waterfallDelegate: SliverWaterfallDelegate(
                crossAxisCount: 1, crossAxisSpacing: 16, mainAxisSpacing: 16),
          ),
        );
      },
    );
  }
}

class _LoadMore extends StatelessWidget {
  const _LoadMore({
    Key key,
    @required this.store,
    @required this.feedId,
  }) : super(key: key);

  final ChildCrossingStore store;
  final int feedId;

  @override
  Widget build(BuildContext context) {
    return SliverLoadMore(
      onLoadMore: () {
        return store.feeds.loadMoreDynamic(feedId);
      },
      isFinish: () => !store.feeds.hasMore,
      builder: (status) {
        if (status == SliverLoadMoreStatus.nomore) {
          return SliverEndScrollListener(
            child: Container(
              padding:
                  EdgeInsets.only(bottom: EHBaseInfo.deviceConst.inset_bottom),
              child: Container(
                  padding: EdgeInsets.only(top: 20, bottom: 20),
                  child: Center(
                      child: Text('- 暂时没有啦，你也去发一段呗 -',
                          style: TextStyle(color: Color(0xffcccccc))))),
            ),
            onScrollEnd: (ScrollEndNotification notification,
                SliverConstraints constraints, SliverGeometry geometry) {
              store.feeds.reportNoMoreShowed(context);
            },
          );
        } else {
          return Container(height: EHBaseInfo.deviceConst.inset_bottom);
        }
      },
    );
  }
}
